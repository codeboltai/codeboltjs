# @agent-creator/agent

## 0.0.1

### Patch Changes

- Updated dependencies [1fd7f63]
- Updated dependencies [5506908]
- Updated dependencies
  - @codebolt/agent-shared-nodes@0.0.3
  - @codebolt/litegraph@0.0.5
  - @codebolt/codeboltjs@5.0.3
  - @codebolt/types@1.0.23
  - @codebolt/agent@5.0.3
