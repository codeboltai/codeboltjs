import { BaseCodeboltAgentNode } from '@codebolt/agent-shared-nodes';
import { CodeboltAgent } from '@codebolt/agent/unified';
import codebolt from '@codebolt/codeboltjs';
import {
    MessageModifier,
    PostInferenceProcessor,
    PostToolCallProcessor,
    PreInferenceProcessor,
    PreToolCallProcessor
} from "@codebolt/types/agent";
import {
    EnvironmentContextModifier,
    CoreSystemPromptModifier,
    DirectoryContextModifier,
    IdeContextModifier,
    AtFileProcessorModifier,
    ToolInjectionModifier,
    ChatHistoryMessageModifier
} from '@codebolt/agent/processor-pieces';

/**
 * CodeboltAgentNode - Backend implementation that wraps the CodeboltAgent class
 * Processes user messages through configurable processors and executes the complete agent loop
 * 
 * Input slots:
 *   0: trigger (ACTION trigger)
 *   1: message (FlatUserMessage)
 *   2: messageModifiers (MessageModifier[])
 *   3: preInferenceProcessors (PreInferenceProcessor[])
 *   4: postInferenceProcessors (PostInferenceProcessor[])
 *   5: preToolCallProcessors (PreToolCallProcessor[])
 *   6: postToolCallProcessors (PostToolCallProcessor[])
 * 
 * Output slots:
 *   0: onComplete (EVENT)
 *   1: onError (EVENT)
 *   2: result (object)
 *   3: success (boolean)
 *   4: error (string)
 */
export class CodeboltAgentNode extends BaseCodeboltAgentNode {
    private agent: CodeboltAgent | null = null;

    constructor() {
        super();
    }

    /**
     * Get default message modifiers if none are provided
     */
    private getDefaultMessageModifiers(systemPrompt: string): MessageModifier[] {
        return [
            // 1. Chat History
            new ChatHistoryMessageModifier({ enableChatHistory: true }),
            // 2. Environment Context (date, OS)
            new EnvironmentContextModifier({ enableFullContext: true }),
            // 3. Directory Context (folder structure)
            new DirectoryContextModifier(),
            // 4. IDE Context (active file, opened files)
            new IdeContextModifier({
                includeActiveFile: true,
                includeOpenFiles: true,
                includeCursorPosition: true,
                includeSelectedText: true
            }),
            // 5. Core System Prompt (instructions)
            new CoreSystemPromptModifier({ customSystemPrompt: systemPrompt }),
            // 6. Tools (function declarations)
            new ToolInjectionModifier({ includeToolDescriptions: true }),
            // 7. At-file processing (@file mentions)
            new AtFileProcessorModifier({ enableRecursiveSearch: true })
        ];
    }

    async onExecute() {
        // Debug: Send message when triggered
        console.log('[DEBUG] CodeboltAgentNode.onExecute triggered');
        await codebolt.chat.sendMessage(`[DEBUG] CodeboltAgentNode.onExecute triggered`, {});

        try {
            const message = this.getInputData(1) as any; // message input
            const inputMessageModifiers = this.getInputData(2) as MessageModifier[] || [];
            const preInferenceProcessors = this.getInputData(3) as PreInferenceProcessor[] || [];
            const postInferenceProcessors = this.getInputData(4) as PostInferenceProcessor[] || [];
            const preToolCallProcessors = this.getInputData(5) as PreToolCallProcessor[] || [];
            const postToolCallProcessors = this.getInputData(6) as PostToolCallProcessor[] || [];

            // Validate inputs
            if (!message) {
                this.setOutputData(2, { success: false, result: null, error: 'Error: Message input is required' });
                this.setOutputData(3, false);
                this.setOutputData(4, 'Error: Message input is required');
                this.triggerSlot(1, null, null); // onError
                return;
            }

            // Get instructions from properties
            const instructions = (this.properties.instructions as string) || 'You are an AI coding assistant.';

            // Use provided message modifiers or default ones
            const messageModifiers = inputMessageModifiers.length > 0
                ? inputMessageModifiers
                : this.getDefaultMessageModifiers(instructions);

            console.log('[DEBUG] Using message modifiers:', messageModifiers.length);
            await codebolt.chat.sendMessage(`[DEBUG] Using ${messageModifiers.length} message modifiers`, {});

            // Create agent configuration from properties and inputs
            const config = {
                instructions: instructions,
                processors: {
                    messageModifiers: messageModifiers,
                    preInferenceProcessors: preInferenceProcessors,
                    postInferenceProcessors: postInferenceProcessors,
                    preToolCallProcessors: preToolCallProcessors,
                    postToolCallProcessors: postToolCallProcessors
                },
                enableLogging: (this.properties.enableLogging as boolean) !== false
            };

            // Create agent instance
            this.agent = new CodeboltAgent(config);

            console.log('[DEBUG] Starting agent.processMessage');
            await codebolt.chat.sendMessage(`[DEBUG] Starting agent.processMessage`, {});

            // Process the message directly
            const result = await this.agent.processMessage(message);

            console.log('[DEBUG] agent.processMessage completed:', result.success);

            // Update outputs with execution result
            this.setOutputData(2, result); // result (slot 2)
            this.setOutputData(3, result.success); // success (slot 3)
            this.setOutputData(4, result.error || null); // error (slot 4)

            // Trigger appropriate event
            if (result.success) {
                this.triggerSlot(0, null, null); // onComplete
            } else {
                this.triggerSlot(1, null, null); // onError
            }

        } catch (error) {
            const errorMessage = `Error: Failed to execute CodeboltAgent - ${error instanceof Error ? error.message : 'Unknown error'}`;
            console.error('CodeboltAgentNode error:', error);
            this.setOutputData(2, { success: false, result: null, error: errorMessage });
            this.setOutputData(3, false);
            this.setOutputData(4, errorMessage);
            this.triggerSlot(1, null, null); // onError
        }
    }
}
