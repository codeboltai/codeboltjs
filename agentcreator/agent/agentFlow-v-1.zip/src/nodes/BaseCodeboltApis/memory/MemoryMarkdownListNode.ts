import { BaseMemoryMarkdownListNode } from '@codebolt/agent-shared-nodes';
import codebolt from '@codebolt/codeboltjs';
import { emitMemoryFailure, emitMemorySuccess, getObjectInput } from './utils.js';

export class MemoryMarkdownListNode extends BaseMemoryMarkdownListNode {
  constructor() {
    super();
  }

  async onExecute() {
    const filters = (getObjectInput(this, 1, 'filters', {}) as Record<string, unknown>) ?? {};

    try {
      const response = await codebolt.memory.markdown.list(filters);
      emitMemorySuccess(this, response);
    } catch (error) {
      emitMemoryFailure(this, 'Failed to list markdown memory entries', error);
    }
  }
}
